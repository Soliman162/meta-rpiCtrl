#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include "LED.hpp"

#define File_Path_string(CopY_num) ("/sys/class/leds/led" + std::to_string(CopY_num) + "/brightness")
#define DELAYON_FILE_PATH(CopY_num) ("/sys/class/leds/led" + std::to_string(CopY_num) + "/delay_on")
#define DELAYOFF_FILE_PATH(CopY_num) ("/sys/class/leds/led" + std::to_string(CopY_num) + "/delay_off")

void File_Write(const std::string file_Path, std::string Value )
{
    LED::dev_file_handler.open(file_Path,std::ios::out);
    LED::dev_file_handler.write(Value.c_str(),Value.size());
    LED::dev_file_handler.close();  
}

LED::LED(LED_STATUS init_status,uint8_t CopY_num):status(init_status),Pin_number(CopY_num)
                                                ,brightness_file_path(File_Path_string(CopY_num))
                                                ,delayON_file_path(DELAYON_FILE_PATH(CopY_num))
                                                ,delayOFF_file_path(DELAYOFF_FILE_PATH(CopY_num))
{
    if( status == ON )
    {
        LED_ON();
    }
    else
    {
        LED_OFF();
    }
}

LED::~LED()
{
    LED_OFF();
}

void LED::LED_ON(void)
{
    std::string Value = std::to_string(ON);
 
    status = ON;
}
void LED::LED_OFF(void)
{
    std::string Value = std::to_string(OFF);
    dev_file_handler.open(brightness_file_path,std::ios::out);
    dev_file_handler.write(Value.c_str(),Value.size());
    dev_file_handler.close();   
    status = OFF;
}

void LED::LED_TOG(void)
{
    std::string Value = std::to_string(~status);
    dev_file_handler.open(brightness_file_path,std::ios::out);
    dev_file_handler.write(Value.c_str(),Value.size());
    dev_file_handler.close();   
    status = static_cast<LED_STATUS>(~status); 
}

LED_STATUS LED::LED_GET_Status(void)
{
    return status;
}
