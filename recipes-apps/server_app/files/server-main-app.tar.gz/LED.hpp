#ifndef LED_H
#define LED_H

#pragma once

void File_Write(const std::string file_Path, std::string Value );

enum LED_STATUS : uint8_t
{
    OFF=0,
    ON=255
};

class LED
{
private:
    const std::string brightness_file_path ;
    const std::string delayON_file_path ;
    const std::string delayOFF_file_path ;
    LED_STATUS status;
    uint8_t Pin_number;
    std::fstream dev_file_handler;
    friend void File_Write(const std::string file_Path, std::string Value );
public:
    LED(LED_STATUS init_status,uint8_t CopY_num);
    ~LED();

    void LED_ON(void);
    void LED_OFF(void);
    void LED_TOG(void);
    LED_STATUS LED_GET_Status(void);
};

#endif